package ca.bcit.bank;

/**
 * Represents a bank account of the client including their information.
 *
 * @author Thando Mpofu
 * @version 1.0
 */

class BankAccount
{
    private final String accountNumber;
    private final BankClient client;
    private double balanceUsd;
    private final int pin;
    private final Date accountOpened;
    private Date accountClosed;

    /**
     * Gets all the financial data of the client.
     *
     * @param accountNumber of the client.
     * @param client info.
     * @param balanceUsd of the client.
     * @param pin of the client.
     * @param accountOpened by client.
     */
    public BankAccount(final String accountNumber,
                       final BankClient client,
                       double balanceUsd,
                       final int pin,
                       final Date accountOpened)
    {
        this.accountNumber = accountNumber;
        this.client = client;
        this.balanceUsd = balanceUsd;
        this.pin = pin;
        this.accountOpened = accountOpened;
    }

    /**
     * For deposits the made to this account.
     *
     * @param amountUsd the account has.
     */
    public void deposit(double amountUsd)
    {
        balanceUsd += amountUsd;
    }

    /**
     * For withdrawals made from this account.
     *
     * @param amountUsd the account has.
     */
    public void withdraw(double amountUsd)
    {
        if (balanceUsd >= amountUsd)
        {
            balanceUsd -= amountUsd;
        }
    }


    /**
     * When is made you need to match the pin.
     *
     * @param amountUsd of the account.
     * @param pinToMatch of the account.
     */
    public void withdraw(double amountUsd, int pinToMatch)
    {
        if (pin == pinToMatch && balanceUsd >= amountUsd)
        {
            balanceUsd -= amountUsd;
        }
    }
}