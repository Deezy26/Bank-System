package ca.bcit.bank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * This is the tester for the Name class.
 *
 * @author Thando Mpofu & ChatGPT
 * @version 1.0
 */
public class NameTest
{

    /**
     * Tests the getFirst method in the name class.
     */
    @Test
    void getFirst()
    {
        Name name = new Name("tigER", "wooDS");
        assertEquals("tigER", name.getFirst());

        name = new Name("eLoN", "MuSk");
        assertEquals("eLoN", name.getFirst());
    }

    @Test
    void getLast() {
        // Add assertions for getLast() method here
    }

    @Test
    void getInitials() {
        // Add assertions for getInitials() method here
    }

    @Test
    void getFullName() {
        // Add assertions for getFullName() method here
    }

    @Test
    void constructorThrows_withBadArgument() {
        // Test that the constructor throws IllegalArgumentException with bad arguments
        Exception exception;

        // Test with null first name
        exception = assertThrows(IllegalArgumentException.class, () -> {
            Name name = new Name(null, "wooDS");
        });
        String expectedMessage = "Invalid name";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));

        // Add more tests for blank first name, first name containing "admin", and first name over 45 characters

        // Test with blank first name
        exception = assertThrows(IllegalArgumentException.class, () -> {
            Name name = new Name("", "wooDS");
        });
        // Add assertions for the expected message

        // Test with first name containing "admin"
        exception = assertThrows(IllegalArgumentException.class, () -> {
            Name name = new Name("John", "adminDoe");
        });
        // Add assertions for the expected message

        // Test with first name over 45 characters
        exception = assertThrows(IllegalArgumentException.class, () -> {
            Name name = new Name("ThisIsAReallyLongFirstNameThatExceeds45Characters", "Doe");
        });
        // Add assertions for the expected message
    }

    // Add more test methods for other Name class methods
}
