package ca.bcit.bank;

import java.util.ArrayList;

/**
 * Represents the bank with the CEO, client accounts, and operations.
 *
 * @author Thando Mpofu
 * @version 1.0
 */

class Bank
{
    private final Person ceo;
    private final ArrayList<BankAccount> accounts;

    /**
     * Gets the CEO of the bank.
     *
     * @param ceo of the bank.
     */
    public Bank(Person ceo)
    {
        this.ceo      = ceo;
        this.accounts = new ArrayList<>();
    }

    /**
     * Adds account to the bank.
     *
     * @param newAccount in the bank system.
     */
    public void addAccount(BankAccount newAccount)
    {
        if (accounts.stream().anyMatch(account -> account.getAccountNumber().equals(newAccount.getAccountNumber()))) {
            throw new IllegalArgumentException("Account with the same account number already exists");
        }
        accounts.add(newAccount);
    }

    /**
     * Removes accounts from the bank.
     *
     * @param accountNumber of the account you want to remove.
     */
    public void removeAccount(String accountNumber)
    {
        accounts.removeIf(account -> account.getAccountNumber().equals(accountNumber));
    }

    /**
     * Displays all the accounts in this bank.
     *
     * @return the list of accounts.
     */
    public BankAccount[] getAllAccounts()
    {
        return accounts.toArray(new BankAccount[0]);
    }

    /**
     * Show the amount of accounts the bank has.
     *
     * @return the amount of accounts.
     */
    public BankAccount getMaxAccount()
    {
        return accounts.stream().max((a1, a2) -> Double.compare(a1.getBalanceUsd(), a2.getBalanceUsd())).orElse(null);
    }

    /**
     * Gets a certain account in the system.
     *
     * @param clientID of the account.
     * @return the account.
     */
    public BankAccount getAccountFor(String clientID)
    {
        return accounts.stream().filter(account -> account.getClient().getClientID().equals(clientID)).findFirst().orElse(null);
    }

    /**
     * Gets the CEO of the bank.
     *
     * @return the CEO.
     */
    public Person getCeo() {
        return ceo;
    }
}