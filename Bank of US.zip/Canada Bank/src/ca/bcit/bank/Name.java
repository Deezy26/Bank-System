package ca.bcit.bank;

/**
 * This code represents the name of the new client of the bank.
 *
 * @author Thando Mpofu
 * @version 1.0
 */
public class Name
{
    private final String first;
    private final String last;


    /**
     * Checks the first and last name if it's not too long or too short.
     *
     * @param first the first name of the client.
     * @param last the last name of the client.
     */
    public Name(final String first,
                final String last)
    {
        if (first == null ||
                last == null ||
                first.isBlank() ||
                last.isBlank() ||
                first.contains("admin") ||
                last.contains("admin") ||
                first.length() > 45 ||
                last.length() > 45)
        {
            throw new IllegalArgumentException("Invalid name");
        }
        this.first = first;
        this.last  = last;
    }

    /**
     * Gets the first name of the new client.
     *
     * @return the first name of the new client.
     */
    public String getFirst()
    {
        return first;
    }

    /**
     * Gets the last name of the new client.
     *
     * @return the last name of the new client.
     */
    public String getLast()
    {
        return last;
    }

    /**
     * Gets the initials of the client.
     *
     * @return the initials of the client.
     */
    public String getInitials()
    {
        return Character.toUpperCase(first.charAt(0)) + "." + Character.toUpperCase(last.charAt(0)) + ".";
    }

    /**
     * Gets the full name of the client.
     *
     * @return the full name of the client.
     */
    public String getFullName() {
        return first.substring(0, 1).toUpperCase() + first.substring(1).toLowerCase() + " " + last.substring(0, 1).toUpperCase() + last.substring(1).toLowerCase();
    }
}
