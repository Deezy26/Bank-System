package ca.bcit.bank;

/**
 * Represents a bank client that extends the Person class with more banking information.
 *
 * @author Thando Mpofu
 * @version 1.0
 */
public class BankClient extends Person
{
    private final String clientID;
    private final Date dateJoinedBank;

    /**
     * The banks client information.
     *
     * @param name of the client.
     * @param birthDate of the client.
     * @param deathDate of the client.
     * @param clientID of the client.
     * @param dateJoinedBank of the client.
     */
    public BankClient(final Name name,
                      final Date birthDate,
                      final Date deathDate,
                      final String clientID,
                      final Date dateJoinedBank)
    {
        super(name,
                birthDate,
                deathDate);

        this.clientID       = clientID;
        this.dateJoinedBank = dateJoinedBank;
    }

    /**
     * Checks the details provided by the client.
     *
     * @return the correct information.
     */
    @Override
    public String getDetails()
    {
        if (super.deathDate != null)
        {
            return super.name.getFullName() + " (died " + super.deathDate.getDayOfWeek() + ", " + super.deathDate.getYYYYMMDD() + ") joined the bank on " + dateJoinedBank.getDayOfWeek() + ", " + dateJoinedBank.getYYYYMMDD();
        } else
        {
            return super.name.getFullName() + " (alive) joined the bank on " + dateJoinedBank.getDayOfWeek() + ", " + dateJoinedBank.getYYYYMMDD() + "!";
        }
    }
}