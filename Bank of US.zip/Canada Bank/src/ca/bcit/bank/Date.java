package ca.bcit.bank;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * This code represents the dates that tell you more about our client.
 *
 * @author Thando Mpofu
 * @version 1.0
 */

class Date
{
    private final int year;
    private final int month;
    private final int day;
    private static final int[] DAYS_IN_MONTH = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    private static final int[] MONTH_CODES = {0, 0, 3, 3, 6, 1, 4, 6, 2, 5, 0, 3, 5};
    private static final int BASE_YEAR = 1900;

    /**
     * Checks the dates that the client enter.
     *
     * @param year  of the clients birth.
     * @param month of the clients birth.
     * @param day   of the clients birth.
     */
    public Date(final int year,
                final int month,
                final int day)
    {
        this.year  = year;
        this.month = month;
        this.day   = day;
    }

    /**
     * Gets the year of the client.
     *
     * @return the year of birth.
     */
    public int getYear()
    {
        return year;
    }

    /**
     * Gets the clients month.
     *
     * @return the month of the client.
     */
    public int getMonth()
    {
        return month;
    }

    /**
     * Gets the Day of the client.
     *
     * @return the day of the client.
     */
    public int getDay()
    {
        return day;
    }

    /**
     * Gets the format of how to display the date in full.
     *
     * @return the full date of the client.
     */
    public String getYYYYMMDD()
    {
        return String.format("%04d-%02d-%02d", year, month, day);
    }

    /**
     * Gets the Day of the week the client by calculating.
     *
     * @return the Day the client.
     */
    public String getDayOfWeek()
    {
        int dayOfWeek = calculateDayOfWeek(year, month, day);
        String[] dayNames =
                {"Sunday",
                        "Monday",
                        "Tuesday",
                        "Wednesday",
                        "Thursday",
                        "Friday",
                        "Saturday"};
        return dayNames[dayOfWeek];
    }

    /**
     * Calculate the Day of the client.
     *
     * @param year uses the year.
     * @param month uses the month.
     * @param day uses the date.
     * @return the Day of the client.
     */
    private int calculateDayOfWeek(int year, int month, int day)
    {
        Calendar calendar = new GregorianCalendar(year, month - 1, day);
        int dayOfWeek     = calendar.get(Calendar.DAY_OF_WEEK);
        dayOfWeek         = (dayOfWeek + 5) % 7;

        return dayOfWeek;
    }

    private boolean isLeapYear(int year)
    {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
}