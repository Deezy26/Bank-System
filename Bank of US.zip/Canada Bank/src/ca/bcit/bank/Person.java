package ca.bcit.bank;

/**
 * This code represents the name, birthdate, & optional death date of the person.
 *
 * @author Thando Mpofu
 * @version 1.0
 */

class Person
{
    private final Name name;
    private final Date birthDate;
    private final Date deathDate;

    /**
     * Gets the name, birthdate, and death date of the client.
     *
     * @param name of the person.
     * @param birthDate of the person.
     * @param deathDate of the person.
     */
    public Person(final Name name,
                  final Date birthDate,
                  final Date deathDate)
    {
        this.name      = name;
        this.birthDate = birthDate;
        this.deathDate = deathDate;
    }

    /**
     * Checks if the person is still alive or dead.
     *
     * @return if the person is dead or alive.
     */
    public String getDetails()
    {
        if (deathDate != null)
        {
            return name.getFullName() + " (died " + deathDate.getDayOfWeek() + ", " + deathDate.getYYYYMMDD() + ") was born on " + birthDate.getDayOfWeek() + ", " + birthDate.getYYYYMMDD() + "!";
        } else
        {
            return name.getFullName() + " (alive) was born on " + birthDate.getDayOfWeek() + ", " + birthDate.getYYYYMMDD() + "!";
        }
    }
}
